#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estructura.h"
#define tam 3

int main()
{
    char seguir='s';
    int opcion=0;
    int espacio=0;

    Epersona listaPersona[3];

   while(seguir=='s')
    {
        printf("1- Agregar persona\n");
        printf("2- Borrar persona\n");
        printf("3- Imprimir lista ordenada por  nombre\n");
        printf("4- Imprimir grafico de edades\n");
        printf("5- Salir\n");

        scanf("%d",&opcion);


        system("pause");
        system("cls");


        switch(opcion)
        {
            case 1:
                {
                if(espacio == 0)
                  {
                    cargarDatos(listaPersona, tam);
                    mostarDatos(listaPersona, tam);
                    espacio++;
                  }

                  else if(espacio == 1)
                  {
                       printf("No hay espacio libre!!!");
                  }

                 espacio= espacioLibre(listaPersona, tam);
                }

                system("pause");
                system("cls");
                break;
            case 2:
                {
                   buscarPorDNI(listaPersona,tam);
                    borrarPersona(listaPersona,tam);
                }

                system("pause");
                system("cls");
                break;
            case 3:
                {
                   ordenarPorNombre(listaPersona, tam);
                   mostarDatos(listaPersona, tam);
                }
                system("pause");
                system("cls");
                break;

            case 4:
                {
                  graficoEdades(listaPersona, tam);
                }
                break;
            case 5:
                seguir = 'n';
                break;
        }

       system("pause");
       system("cls");
    }


    return 0;
}
