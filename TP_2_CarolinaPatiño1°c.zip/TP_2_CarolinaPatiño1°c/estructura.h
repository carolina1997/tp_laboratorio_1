typedef struct {

    char nombre[50];
    int edad;
    int estado;
    int dni;

}Epersona;

void cargarDatos(Epersona[], int);

void mostrarDatos(Epersona[], int);

int borrarPersona(Epersona[], int);

int espacioLibre(Epersona[], int);

void ordenarPorNombre(Epersona[], int);

int buscarPorDNI(Epersona[], int);

void graficoEdades(Epersona[], int);
