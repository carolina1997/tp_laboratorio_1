#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "estructura.h"



void cargarDatos(Epersona listaPersona[], int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        printf("Ingrese nombre:");
        fflush(stdin);
        gets(listaPersona[i].nombre);

        printf("Ingrese edad:");
        scanf("%d", &listaPersona[i].edad);

        printf("Ingrese DNI:");
        scanf("%d", &listaPersona[i].dni);

        listaPersona[i].estado= 1;

    }
}

void mostarDatos(Epersona listaPersona[], int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
      printf("%s\n %d\n %d\n %d\n", listaPersona[i].nombre, listaPersona[i].edad, listaPersona[i].dni, listaPersona[i].estado);

    }
}

int borrarPersona(Epersona listaPersona[], int tam)
{
    int  i, auxDNI;
    char respuesta;
    int flagEncontrarDNI=0;
    printf("Ingrese DNI: ");
    scanf("%d", &auxDNI);
    for(i=0; i<tam;i++)
    {

        if((listaPersona[i].dni)== auxDNI)
        {
             printf("Esta seguro que desea dar de baja esta persona? s/n: %d", listaPersona[i].dni);
            respuesta = getche();
            if(respuesta=='s')
            {
                listaPersona[i].estado = 0;
            }
            else
            {
                printf("Accion cancelada!!!");
            }

            flagEncontrarDNI = 1;
            break;
        }

    }
    if(!flagEncontrarDNI)
    {
        printf("NO se encontro DNI solicitado");
    }



}

int espacioLibre(Epersona listaPersona[], int tam)
{
    int i;
    for(i=0; i<tam;i++)
    {
        if(listaPersona[i].estado == 0)
        {
            return i;
        }
    }
    return -1;
}



void ordenarPorNombre(Epersona listaPersona[], int tam)
{
    Epersona auxPersona;
    int i, j;
    for(i=0;i<tam-1;i++)
    {
        if(listaPersona[i].estado==0)
        {
            continue;
        }
        for(j=i+1;j<tam;j++)
        {
            if(listaPersona[i].estado == 0)
            {
                continue;
            }
            if(strcmp(listaPersona[j].nombre, listaPersona[i].nombre)< 0)
            {
                auxPersona=listaPersona[j];
                listaPersona[j] = listaPersona[i];
                listaPersona[i] = auxPersona;
            }
        }

    }
}

int buscarPorDNI(Epersona listaPersona[], int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        if((listaPersona[i].dni) && (listaPersona[i].estado)== -1)
        {
            return i;
        }
        return 0;
    }
}

void graficoEdades(Epersona listaPersona[], int tam)
{
    int contadorMenor18=0, contador19a35=0, contadorMayor35=0;
    int i;
    char grafico[3][3];
    for(i=0;i<tam;i++)
    {
        grafico[0][i]= printf("\n");
        grafico[1][i]= printf("\n");
        grafico[2][i]= printf("\n");
    }
     for(i=0;i<tam;i++)
     {
         if(listaPersona[i].edad<18)
         {
             contadorMenor18++;
         }
         if(listaPersona[i].edad>35)
         {
             contadorMayor35++;
         }
        if(listaPersona[i].edad>=19 && listaPersona[i].edad<=35)
         {
             contador19a35++;
         }
    }
        for(i=0;i<tam;i++)
     {
         if(i<contadorMenor18)
         {
             grafico[0][i]= printf("menores de 18:*\n");
         }
         if(i<contadorMayor35)
         {
             grafico[1][i]= printf("mayores de 35:*\n");
         }
        if(i<contador19a35)
         {
            grafico[2][i]= printf("de 19 a 35*\n");
         }
    }
}
